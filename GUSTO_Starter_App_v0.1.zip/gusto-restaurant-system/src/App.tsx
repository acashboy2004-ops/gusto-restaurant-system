import { useEffect, useMemo, useState } from 'react'
import {
  LayoutDashboard, ShoppingCart, ChefHat, Utensils, BookOpen, Boxes, Truck,
  Receipt, Users, Zap, Armchair, BarChart3, Settings, Search, Bell, Plus,
  Minus, Trash2, Clock3, CheckCircle2, CircleDollarSign, TrendingUp, Package,
  Menu as MenuIcon, X, Wifi, WifiOff, LogOut, Download, ArrowUpRight
} from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import { isSupabaseConfigured } from './lib/supabase'

type Product = { id:number; name:string; category:string; price:number; available:boolean }
type CartLine = { product:Product; qty:number; note:string }
type Order = { id:number; lines:CartLine[]; total:number; status:string; type:string; table:string; time:string }
type Expense = { id:number; name:string; category:string; amount:number; date:string }

const initialProducts:Product[] = [
  {id:1,name:'Chicken Fried Rice',category:'Rice',price:1250,available:true},
  {id:2,name:'Beef Kottu',category:'Kottu',price:1450,available:true},
  {id:3,name:'Chicken Biriyani',category:'Biriyani',price:1650,available:true},
  {id:4,name:'Seafood Nasi Goreng',category:'Nasi Goreng',price:1850,available:true},
  {id:5,name:'Iced Coffee',category:'Beverages',price:650,available:true},
  {id:6,name:'Chocolate Milkshake',category:'Beverages',price:850,available:true},
  {id:7,name:'Chicken Devilled',category:'Chicken',price:1750,available:true},
  {id:8,name:'French Fries',category:'Snacks',price:750,available:true},
]
const nav = [
  {name:'Dashboard',si:'දෛනික පාලක පුවරුව',icon:LayoutDashboard},
  {name:'POS & Orders',si:'විකුණුම් සහ ඇණවුම්',icon:ShoppingCart},
  {name:'Kitchen Display',si:'මුළුතැන්ගෙයි තිරය',icon:ChefHat},
  {name:'Menu Management',si:'ආහාර ලැයිස්තුව',icon:Utensils},
  {name:'Recipes & Food Cost',si:'වට්ටෝරු සහ ආහාර පිරිවැය',icon:BookOpen},
  {name:'Inventory',si:'තොග පාලනය',icon:Boxes},
  {name:'Suppliers & Purchases',si:'සැපයුම්කරුවන් සහ මිලදී ගැනීම්',icon:Truck},
  {name:'Expenses',si:'වියදම්',icon:Receipt},
  {name:'Staff & Salaries',si:'සේවකයින් සහ වැටුප්',icon:Users},
  {name:'Utilities',si:'විදුලිය, ජලය සහ අනෙකුත් බිල්',icon:Zap},
  {name:'Tables',si:'මේස කළමනාකරණය',icon:Armchair},
  {name:'Reports & Analytics',si:'වාර්තා සහ විශ්ලේෂණ',icon:BarChart3},
  {name:'Settings',si:'සැකසුම්',icon:Settings},
]
const money = (n:number) => new Intl.NumberFormat('en-LK',{style:'currency',currency:'LKR',maximumFractionDigits:0}).format(n)
const load = <T,>(key:string, fallback:T):T => { try { const v=localStorage.getItem(key); return v?JSON.parse(v):fallback } catch { return fallback } }

export default function App() {
  const [active,setActive] = useState('Dashboard')
  const [mobileOpen,setMobileOpen] = useState(false)
  const [products,setProducts] = useState<Product[]>(()=>load('gusto_products',initialProducts))
  const [orders,setOrders] = useState<Order[]>(()=>load('gusto_orders',[]))
  const [expenses,setExpenses] = useState<Expense[]>(()=>load('gusto_expenses',[]))
  const [cart,setCart] = useState<CartLine[]>([])
  const [category,setCategory] = useState('All')
  const [search,setSearch] = useState('')
  const [orderType,setOrderType] = useState('Dine-in')
  const [table,setTable] = useState('T1')
  const [toast,setToast] = useState('')
  const [expenseName,setExpenseName] = useState('')
  const [expenseAmount,setExpenseAmount] = useState('')
  const [expenseCategory,setExpenseCategory] = useState('Food Purchases')
  const [newProduct,setNewProduct] = useState({name:'',category:'Rice',price:''})

  useEffect(()=>{localStorage.setItem('gusto_products',JSON.stringify(products))},[products])
  useEffect(()=>{localStorage.setItem('gusto_orders',JSON.stringify(orders))},[orders])
  useEffect(()=>{localStorage.setItem('gusto_expenses',JSON.stringify(expenses))},[expenses])
  useEffect(()=>{if(!toast)return; const t=setTimeout(()=>setToast(''),2600);return()=>clearTimeout(t)},[toast])

  const today = new Date().toISOString().slice(0,10)
  const todayOrders = orders.filter(o=>o.time.slice(0,10)===today && o.status!=='Cancelled')
  const todaySales = todayOrders.reduce((s,o)=>s+o.total,0)
  const todayExpenses = expenses.filter(e=>e.date===today).reduce((s,e)=>s+e.amount,0)
  const pending = orders.filter(o=>['New','Accepted','Preparing','Ready'].includes(o.status)).length
  const categories = ['All',...Array.from(new Set(products.map(p=>p.category)))]
  const filtered = products.filter(p=>p.available && (category==='All'||p.category===category) && p.name.toLowerCase().includes(search.toLowerCase()))
  const cartTotal = cart.reduce((s,l)=>s+l.product.price*l.qty,0)
  const add = (p:Product)=>setCart(old=>{const found=old.find(l=>l.product.id===p.id);return found?old.map(l=>l.product.id===p.id?{...l,qty:l.qty+1}:l):[...old,{product:p,qty:1,note:''}]})
  const updateStatus = (id:number,status:string)=>setOrders(old=>old.map(o=>o.id===id?{...o,status}:o))
  const submitOrder = ()=>{
    if(!cart.length){setToast('Add at least one item to the order.');return}
    const order:Order={id:Date.now(),lines:cart,total:cartTotal,status:'New',type:orderType,table:orderType==='Dine-in'?table:'—',time:new Date().toISOString()}
    setOrders(old=>[order,...old]);setCart([]);setToast(`Order #${String(order.id).slice(-5)} sent to kitchen`)
  }
  const addExpense=()=>{
    const amount=Number(expenseAmount)
    if(!expenseName.trim()||!amount||amount<=0){setToast('Enter an expense name and a valid amount.');return}
    setExpenses(old=>[{id:Date.now(),name:expenseName,category:expenseCategory,amount,date:today},...old])
    setExpenseName('');setExpenseAmount('');setToast('Expense saved on this device')
  }
  const addMenuItem=()=>{
    const price=Number(newProduct.price)
    if(!newProduct.name.trim()||!price||price<=0){setToast('Enter an item name and valid price.');return}
    setProducts(old=>[...old,{id:Date.now(),name:newProduct.name,category:newProduct.category,price,available:true}])
    setNewProduct({name:'',category:'Rice',price:''});setToast('Menu item added')
  }
  const chartData = useMemo(()=>['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map((d,i)=>({day:d,sales:orders.filter(o=>new Date(o.time).getDay()===(i+1)%7).reduce((s,o)=>s+o.total,0)})),[orders])
  const currencyHint = 'All amounts are in Sri Lankan Rupees (LKR).'

  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen?'open':''}`}>
      <div className="brand"><div className="brand-mark">G</div><div><div className="brand-name">GUSTO</div><div className="brand-sub">RESTAURANT MANAGEMENT</div></div><button className="mobile-close" onClick={()=>setMobileOpen(false)}><X size={19}/></button></div>
      <div className="side-label">WORKSPACE</div>
      <nav>{nav.map(item=>{const Icon=item.icon;return <button key={item.name} className={`nav-item ${active===item.name?'active':''}`} onClick={()=>{setActive(item.name);setMobileOpen(false)}}><Icon size={18}/><span><b>{item.name}</b><small>{item.si}</small></span></button>})}</nav>
      <div className="sidebar-bottom"><div className="plan-pill"><span className="dot"/> FREE STARTER WORKSPACE</div><div className="user-mini"><div className="avatar">O</div><div><b>Restaurant Owner</b><small>Demo workspace</small></div><LogOut size={16}/></div></div>
    </aside>
    {mobileOpen&&<div className="scrim" onClick={()=>setMobileOpen(false)}/>}
    <main className="main-area">
      <header className="topbar"><div className="top-left"><button className="menu-toggle" onClick={()=>setMobileOpen(true)}><MenuIcon/></button><div className="breadcrumb">Workspace <span>/</span> <b>{active}</b></div></div><div className="top-actions"><div className={`connection ${isSupabaseConfigured?'connected':''}`}>{isSupabaseConfigured?<Wifi size={15}/>:<WifiOff size={15}/>} {isSupabaseConfigured?'Supabase configured':'Local demo mode'}</div><button className="icon-btn" title="Notifications"><Bell size={18}/></button><div className="avatar small">O</div></div></header>
      <div className="page-content">
        {active==='Dashboard'&&<Dashboard sales={todaySales} expenses={todayExpenses} orders={todayOrders.length} pending={pending} chartData={chartData} ordersList={orders} currencyHint={currencyHint}/>}
        {active==='POS & Orders'&&<section><PageHeading title="Point of Sale" subtitle="Create orders, manage carts and send tickets to the kitchen."/><div className="pos-layout"><div className="panel menu-panel"><div className="panel-head"><div><h3>Menu items</h3><p>Select items to add to the order</p></div><div className="searchbox"><Search size={16}/><input placeholder="Search menu..." value={search} onChange={e=>setSearch(e.target.value)}/></div></div><div className="chips">{categories.map(c=><button key={c} className={category===c?'chip selected':'chip'} onClick={()=>setCategory(c)}>{c}</button>)}</div><div className="product-grid">{filtered.map(p=><button className="product-tile" key={p.id} onClick={()=>add(p)}><span className="product-symbol">{p.category==='Beverages'?'🥤':p.category==='Snacks'?'🍟':'🍽️'}</span><b>{p.name}</b><small>{p.category}</small><strong>{money(p.price)}</strong><span className="add-circle"><Plus size={16}/></span></button>)}</div></div><div className="panel cart-panel"><div className="panel-head"><div><h3>Current order</h3><p>{cart.length} item types</p></div><button className="text-btn" onClick={()=>setCart([])}>Clear</button></div><div className="order-options"><label>Order type<select value={orderType} onChange={e=>setOrderType(e.target.value)}><option>Dine-in</option><option>Takeaway</option><option>Delivery</option></select></label>{orderType==='Dine-in'&&<label>Table<select value={table} onChange={e=>setTable(e.target.value)}>{Array.from({length:12},(_,i)=><option key={i}>T{i+1}</option>)}</select></label>}</div><div className="cart-lines">{cart.length===0?<div className="empty-state"><ShoppingCart size={30}/><b>Your cart is empty</b><span>Add menu items to begin</span></div>:cart.map(l=><div className="cart-line" key={l.product.id}><div className="cart-info"><b>{l.product.name}</b><small>{money(l.product.price)} each</small></div><div className="qty"><button onClick={()=>setCart(old=>old.map(x=>x.product.id===l.product.id?{...x,qty:Math.max(0,x.qty-1)}:x).filter(x=>x.qty>0))}><Minus size={13}/></button><b>{l.qty}</b><button onClick={()=>add(l.product)}><Plus size={13}/></button></div><strong>{money(l.qty*l.product.price)}</strong></div>)}</div><div className="cart-total"><div><span>Subtotal</span><b>{money(cartTotal)}</b></div><div className="grand"><span>Total</span><strong>{money(cartTotal)}</strong></div><button className="primary-btn full" onClick={submitOrder}>Send order to kitchen <ArrowUpRight size={17}/></button><small className="muted center">Payment collection and receipt printing are not connected in this starter.</small></div></div></div></section>}
        {active==='Kitchen Display'&&<section><PageHeading title="Kitchen Display System" subtitle="Live order queue view. Orders appear here when submitted from POS."/><div className="kitchen-columns">{['New','Accepted','Preparing','Ready'].map(status=><div className="kitchen-column" key={status}><div className="column-title"><b>{status}</b><span>{orders.filter(o=>o.status===status).length}</span></div>{orders.filter(o=>o.status===status).map(o=><div className="ticket" key={o.id}><div className="ticket-top"><b>#{String(o.id).slice(-5)}</b><span>{new Date(o.time).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</span></div><div className="ticket-meta">{o.type} · {o.table}</div>{o.lines.map(l=><div className="ticket-item" key={l.product.id}><b>{l.qty}×</b> {l.product.name}</div>)}<div className="ticket-bottom"><strong>{money(o.total)}</strong><select value={o.status} onChange={e=>updateStatus(o.id,e.target.value)}>{['New','Accepted','Preparing','Ready','Served','Completed','Cancelled'].map(s=><option key={s}>{s}</option>)}</select></div></div>)}</div>)}</div></section>}
        {active==='Menu Management'&&<section><PageHeading title="Menu Management" subtitle="Manage products, categories, availability and selling prices."/><div className="panel"><div className="panel-head"><div><h3>Add menu item</h3><p>Starter data is stored in this browser</p></div></div><div className="inline-form"><input placeholder="Item name" value={newProduct.name} onChange={e=>setNewProduct({...newProduct,name:e.target.value})}/><select value={newProduct.category} onChange={e=>setNewProduct({...newProduct,category:e.target.value})}>{['Rice','Kottu','Nasi Goreng','Biriyani','Set Menu','Seafood','Beef','Chicken','Snacks','Beverages','Desserts','Special Offers'].map(x=><option>{x}</option>)}</select><input type="number" placeholder="Price (LKR)" value={newProduct.price} onChange={e=>setNewProduct({...newProduct,price:e.target.value})}/><button className="primary-btn" onClick={addMenuItem}><Plus size={16}/> Add item</button></div><DataTable headers={['Item','Category','Selling price','Availability','Action']}>{products.map(p=><tr key={p.id}><td><b>{p.name}</b></td><td>{p.category}</td><td>{money(p.price)}</td><td><span className="status green">Available</span></td><td><button className="small-action" onClick={()=>setProducts(old=>old.filter(x=>x.id!==p.id))}><Trash2 size={15}/></button></td></tr>)}</DataTable></div></section>}
        {active==='Expenses'&&<section><PageHeading title="Expense Management" subtitle="Record and review restaurant operating expenses."/><div className="panel"><div className="panel-head"><div><h3>Record an expense</h3><p>Expense entries update the dashboard totals</p></div></div><div className="inline-form"><input placeholder="Expense description" value={expenseName} onChange={e=>setExpenseName(e.target.value)}/><select value={expenseCategory} onChange={e=>setExpenseCategory(e.target.value)}>{['Food Purchases','Staff Expenses','Rent','Electricity','Water','Gas','Internet','Transport','Repairs and Maintenance','Packaging','Marketing','Other Expenses'].map(x=><option>{x}</option>)}</select><input type="number" placeholder="Amount (LKR)" value={expenseAmount} onChange={e=>setExpenseAmount(e.target.value)}/><button className="primary-btn" onClick={addExpense}><Plus size={16}/> Save expense</button></div><DataTable headers={['Date','Description','Category','Amount']}>{expenses.map(e=><tr key={e.id}><td>{e.date}</td><td><b>{e.name}</b></td><td>{e.category}</td><td>{money(e.amount)}</td></tr>)}</DataTable></div></section>}
        {active==='Tables'&&<section><PageHeading title="Table Management" subtitle="A simple floor overview for dine-in service."/><div className="table-grid">{Array.from({length:12},(_,i)=>{const name=`T${i+1}`;const occupied=orders.some(o=>o.table===name&&!['Completed','Cancelled'].includes(o.status));return <div className={`restaurant-table ${occupied?'occupied':''}`} key={name}><Armchair size={24}/><b>{name}</b><small>{occupied?'Occupied':'Available'}</small></div>})}</div></section>}
        {active==='Inventory'&&<section><PageHeading title="Inventory & Stock Control" subtitle="Starter inventory overview. Connect the database before operational stock tracking."/><div className="notice"><Package size={19}/><div><b>Inventory integration is the next build phase</b><p>Recipe-based deductions, stock movements, expiry tracking and supplier-linked purchases require the database migration and transactional stock functions.</p></div></div><DataTable headers={['Ingredient','Category','On hand','Unit','Minimum level','Status']}>{[['Chicken','Meat','18','kg','5','In stock'],['Rice','Grains','42','kg','10','In stock'],['Cooking oil','Pantry','3','L','5','Low stock'],['Onion','Vegetables','8','kg','4','In stock'],['Cheese','Dairy','2','kg','3','Low stock']].map(r=><tr>{r.map((v,i)=><td>{i===5?<span className={`status ${v==='Low stock'?'warning':'green'}`}>{v}</span>:v}</td>)}</tr>)}</DataTable></section>}
        {active==='Reports & Analytics'&&<section><PageHeading title="Reports & Analytics" subtitle="Sales and expense summaries from the records in this browser."/><div className="stats-grid"><Stat icon={CircleDollarSign} label="Recorded sales" value={money(orders.reduce((s,o)=>s+o.total,0))}/><Stat icon={Receipt} label="Recorded expenses" value={money(expenses.reduce((s,e)=>s+e.amount,0))}/><Stat icon={TrendingUp} label="Sales less expenses" value={money(orders.reduce((s,o)=>s+o.total,0)-expenses.reduce((s,e)=>s+e.amount,0))}/></div><div className="panel chart-panel"><h3>Sales by weekday</h3><ResponsiveContainer width="100%" height={280}><BarChart data={chartData}><CartesianGrid strokeDasharray="3 3" vertical={false}/><XAxis dataKey="day"/><YAxis/><Tooltip formatter={(v)=>money(Number(v))}/><Bar dataKey="sales" fill="#c8a45d" radius={[6,6,0,0]}/></BarChart></ResponsiveContainer></div></section>}
        {active==='Recipes & Food Cost'&&<InfoPage title="Recipes & Food Cost" description="Recipe ingredients, measurement units, unit costs, packaging and preparation costs will be connected to inventory in the next phase." items={['Ingredient quantities and units','Recipe cost recalculation','Food cost percentage','Gross profit per menu item']}/>}
        {active==='Suppliers & Purchases'&&<InfoPage title="Suppliers & Purchases" description="Supplier accounts and purchase receiving are planned for the database-backed operations phase." items={['Supplier directory','Purchase orders','Supplier invoices','Outstanding balances']}/>}
        {active==='Staff & Salaries'&&<InfoPage title="Staff & Salaries" description="Staff records, attendance and salary workflows will be added with authenticated user profiles." items={['Staff directory','Salary and advances','Allowances and deductions','Attendance and leave']}/>}
        {active==='Utilities'&&<InfoPage title="Utilities Management" description="Track billing periods, due dates and paid/unpaid utility records." items={['Electricity bills','Water bills','Gas bills','Internet and other utilities']}/>}
        {active==='Settings'&&<SettingsPage/>}
      </div>
      <footer className="footer">GUSTO <span>·</span> Your Restaurant. Your Control. <span>·</span> Starter build v0.1</footer>
    </main>
    {toast&&<div className="toast"><CheckCircle2 size={17}/>{toast}</div>}
  </div>
}

function PageHeading({title,subtitle}:{title:string;subtitle:string}){return <div className="page-heading"><div><div className="eyebrow">GUSTO WORKSPACE</div><h1>{title}</h1><p>{subtitle}</p></div><div className="date-chip">{new Date().toLocaleDateString('en-LK',{weekday:'short',day:'2-digit',month:'short',year:'numeric'})}</div></div>}
function Stat({icon:Icon,label,value,detail}:{icon:any;label:string;value:string;detail?:string}){return <div className="stat-card"><div className="stat-top"><span>{label}</span><div className="stat-icon"><Icon size={18}/></div></div><strong>{value}</strong><small>{detail||'Current workspace total'}</small></div>}
function DataTable({headers,children}:{headers:string[];children:any}){return <div className="table-wrap"><table><thead><tr>{headers.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{children}</tbody></table></div>}
function Dashboard({sales,expenses,orders,pending,chartData,ordersList,currencyHint}:{sales:number;expenses:number;orders:number;pending:number;chartData:any[];ordersList:Order[];currencyHint:string}){
  return <section><PageHeading title="Good morning, Owner" subtitle="Here is your restaurant's performance overview."/><div className="welcome-strip"><div><span className="eyebrow gold">THURSDAY · DAILY OVERVIEW</span><h2>Your restaurant. <em>Your control.</em></h2><p>{currencyHint}</p></div><div className="welcome-mark">G</div></div><div className="stats-grid"><Stat icon={CircleDollarSign} label="Today's sales" value={money(sales)} detail={`${orders} orders recorded`}/><Stat icon={Receipt} label="Today's expenses" value={money(expenses)} detail="Recorded today"/><Stat icon={TrendingUp} label="Sales less expenses" value={money(sales-expenses)} detail="Not net profit; food cost not included"/><Stat icon={Clock3} label="Pending orders" value={String(pending)} detail="Kitchen queue"/></div><div className="dashboard-grid"><div className="panel chart-panel"><div className="panel-head"><div><h3>Sales activity</h3><p>Recorded order totals by weekday</p></div><span className="subtle-tag">THIS WEEK</span></div><ResponsiveContainer width="100%" height={255}><BarChart data={chartData}><CartesianGrid strokeDasharray="3 3" vertical={false}/><XAxis dataKey="day" axisLine={false} tickLine={false}/><YAxis axisLine={false} tickLine={false}/><Tooltip formatter={(v)=>money(Number(v))}/><Bar dataKey="sales" fill="#c8a45d" radius={[6,6,0,0]} barSize={30}/></BarChart></ResponsiveContainer></div><div className="panel"><div className="panel-head"><div><h3>Order status</h3><p>Current kitchen workflow</p></div></div><div className="status-list">{['New','Accepted','Preparing','Ready','Completed','Cancelled'].map(s=><div><span className={`status-dot ${s.toLowerCase()}`}/><span>{s}</span><b>{ordersList.filter(o=>o.status===s).length}</b></div>)}</div></div></div><div className="panel recent-panel"><div className="panel-head"><div><h3>Recent orders</h3><p>Latest orders created in this workspace</p></div></div><DataTable headers={['Order','Time','Type','Items','Total','Status']}>{ordersList.slice(0,6).map(o=><tr><td><b>#{String(o.id).slice(-5)}</b></td><td>{new Date(o.time).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</td><td>{o.type}</td><td>{o.lines.reduce((s,l)=>s+l.qty,0)}</td><td>{money(o.total)}</td><td><span className="status blue">{o.status}</span></td></tr>)}</DataTable>{ordersList.length===0&&<div className="empty-inline">No orders yet. Open POS & Orders to create your first order.</div>}</div></section>
}
function InfoPage({title,description,items}:{title:string;description:string;items:string[]}){return <section><PageHeading title={title} subtitle={description}/><div className="panel roadmap"><div className="roadmap-icon"><BookOpen size={24}/></div><h3>Module foundation</h3><p>{description}</p><div className="roadmap-list">{items.map(x=><div><CheckCircle2 size={17}/>{x}</div>)}</div><span className="status warning">Database integration pending</span></div></section>}
function SettingsPage(){return <section><PageHeading title="Settings" subtitle="Restaurant identity and application configuration."/><div className="settings-grid"><div className="panel setting-card"><h3>Restaurant profile</h3><label>Restaurant name<input defaultValue="GUSTO Restaurant"/></label><label>Tagline<input defaultValue="Your Restaurant. Your Control."/></label><label>Currency<select defaultValue="LKR"><option>LKR</option></select></label><label>Interface language<select defaultValue="English + Sinhala"><option>English + Sinhala</option></select></label></div><div className="panel setting-card"><h3>System connection</h3><div className="connection-row"><span>Supabase</span><b>{isSupabaseConfigured?'Configured':'Not configured'}</b></div><p className="muted">Add your Supabase URL and publishable/anon key to the local environment file. Apply the SQL migration and configure authentication before using cloud features.</p><div className="connection-row"><span>Storage mode</span><b>{isSupabaseConfigured?'Cloud client configured':'Browser local storage'}</b></div><div className="connection-row"><span>Automatic backups</span><b>Not configured</b></div></div></div></section>}
