# GUSTO — Restaurant Management System

**Your Restaurant. Your Control.**  
Currency: LKR · Interface: English with secondary Sinhala labels

This is the **GUSTO starter application (v0.1)**. It provides a responsive application shell, working browser-local POS order entry, a kitchen queue, menu item entry, expense entry, table overview, dashboard and starter Supabase schema.

## Important status

- The application currently runs in **local demo mode** and stores starter POS/menu/expense data in the current browser's `localStorage`.
- Supabase is **not connected** until you create a project, apply the migration, configure authentication and add your project URL/key.
- The kitchen screen in this starter reads orders created in the same browser. Cross-device Realtime sync is a next implementation step.
- Inventory deductions, recipe-cost calculations, supplier purchasing, salaries, utility workflows, receipt printing, payment recording, backups and production audit triggers are not yet implemented.
- Demo products and sample inventory rows are illustrative only. They are not actual restaurant records.
- This starter does not collect or process online payments.

Do not use this starter as the sole production record system until cloud persistence, transactional stock handling, authorization and backups have been implemented and tested.

## Requirements

- Node.js 20+
- A free GitHub account (optional, for source control)
- A free Cloudflare account (optional, for deployment)
- A Supabase project on its Free plan (optional until cloud integration)

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Build

```bash
npm run build
npm run preview
```

## Supabase setup

1. Create a Supabase project on the Free plan.
2. Open the Supabase SQL Editor and run `supabase/migrations/001_initial_schema.sql`.
3. Configure Authentication providers and email settings in Supabase.
4. Create the first restaurant row and owner profile using a trusted setup process. Do not expose the service-role key in frontend code.
5. Copy `.env.example` to `.env.local`.
6. Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` (or publishable key, as supported by your Supabase project).
7. Restart the dev server.

The included migration is a database foundation, not a finished production security review. In particular, initial owner onboarding and invitation flows must be implemented before staff can securely join a restaurant. Test every RLS policy with separate owner/staff accounts.

## Free hosting

- Build the app with `npm run build`.
- Deploy the generated `dist/` directory to Cloudflare Pages.
- Set the two `VITE_SUPABASE_*` environment variables in the Cloudflare Pages project settings.
- Use a GitHub private repository if you want the source code kept private.

Free-tier limits can change. Supabase Free projects may pause after inactivity and do not include automatic backups. Export database backups on a separate schedule and keep copies somewhere secure. Cloud hosting free plans are not an uptime or business-continuity guarantee.

## Next implementation milestones

1. Secure authentication, restaurant onboarding and user profile membership.
2. Supabase CRUD for menu, orders, expenses, staff, suppliers and tables.
3. Database transaction/RPC for order submission, split payments and idempotent recipe stock deductions.
4. Supabase Realtime KDS synchronization across devices.
5. Recipe costing and inventory batches/stock movements/expiry.
6. Purchasing, supplier balances, salary, utility and audit workflows.
7. Financial reports with clear gross-profit, operating-expense and net-profit definitions.
8. Thermal receipt printing, exports, backups, restore testing and security review.
